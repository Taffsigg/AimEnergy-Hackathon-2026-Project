Metadata for measured load profiles concering the publication "Comparision of load profiles in a mini-grid: assessment of performance metrics using measured and interview-based data.
Type: Measurement start day: mesurement start time
Household: : 8:20
Workshop1a: Friday : 11:00
Workshop1b: Monday : 12:39
Mill1: Friday : 10:00
Mill2a: Thursday : 8:25
Mill2b: Saturday : 8:45
Minigrid1a: Thursday : 11:25
Minigrid1b: Monday : 11:40
Hospital: Wednesday : 9:15