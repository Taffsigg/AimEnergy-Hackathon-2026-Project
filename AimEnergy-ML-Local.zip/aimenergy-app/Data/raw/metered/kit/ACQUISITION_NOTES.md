# KIT public archive acquisition

The standard free public RADAR terms were reviewed and accepted in this task. No account, identity assertion, payment or institutional service commitment was made.

The raw archive is NOT complete. `10.35097-1305.tar.part` and `archive-prefix.bin` must not be used for metrics. No complete metered series has been acquired. README/XML files are complete but do not establish raw measurement units.

From the app directory, resume the bounded download with:

```powershell
python scripts/acquire_kit_data.py --terms-reviewed-and-accepted --max-time-seconds 14400
```

The script uses verified TLS and HTTP resume, stops on failure, and never retries automatically. If HTTP 429 occurs, wait at least five minutes (or the server Retry-After interval) before a manual retry. Do not change identity or hosts to evade quotas. A four-hour download limit is a maximum, not a promise of completion.

Only a complete 988638720-byte archive matching published MD5 2e9a2a7579a1e36a005753290cfd6c17 is accepted. The script then records SHA-256 and extracts documentation and Haiti files without executing downloaded code. Raw unit/timezone/coverage checks still must follow.

Citation: Luh, Matthias; Phipps, Kaleb; Britto, Anthony; et al. (2023). High-Resolution Real-World Electricity Data from Three Microgrids in the Global South. Karlsruhe Institute of Technology. https://doi.org/10.35097/1305. Dataset CC BY 4.0, https://creativecommons.org/licenses/by/4.0/. Preserve attribution and mark derived changes. The packaging README itself bears Apache 2.0 notice.
